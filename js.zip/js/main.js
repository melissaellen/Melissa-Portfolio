$(document).ready(function() {
	$('.portfolio').hide();
	$('#portfolio h4').click(function() {
		var $portfolio = $(this).next('.portfolio');
		if ($portfolio.is(':hidden')) {
			$portfolio.slideDown();
			$(this).addClass('close');
		}else{
			$portfolio.fadeOut();
			$(this).removeClass('close');
		}
	});
