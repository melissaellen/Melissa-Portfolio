var numberOfFaces = 5;

function generateFaces(){
	var theLeftSide  = document.getElementById("leftSide");
	var theRightSide = document.getElementById("rightSide");
	
	for(var i = 0; i < numberOfFaces; i++){
		var smile_img = document.createElement("IMG");
		smile_img.setAttribute("src", "nook-face.png");
		var rand_top = Math.random() * 350;
		rand_top = Math.floor(rand_top);
		var rand_left = Math.random() * 350;
		rand_left = Math.floor(rand_left);
		
		smile_img.style.top = rand_top + "px";
		smile_img.style.left = rand_left + "px";
		
		theLeftSide.appendChild(smile_img);
		var leftSideImages = theLeftSide.cloneNode(true);
		theRightSide.appendChild(leftSideImages);
		leftSideImages.removeChild(leftSideImages.lastChild);
	}
		
	var theBody = document.getElementsByTagName("body")[0];
		
theLeftSide.lastChild.onclick = function nextlevel(event){
	alert ("Good job! Onto the next level!");
	event.stopPropagation();
	
	while (theLeftSide.hasChildNodes()){
		theLeftSide.removeChild(theLeftSide.lastChild);
		theRightSide.removeChild(theRightSide.lastChild);
	
		//alert ("removed child");
	};
	
	//alert ("new game");
	numberOfFaces += 5;
	generateFaces();
	

};
	

theBody.onclick = function gameOver(){
	alert ("Game Over! Restarting game...");
	theBody.onclick = null;
	theLeftSide.lastChild.onclick = null;
	location.reload();
};
	

};