    $(document).ready(function() {
	$('.pl-heading').click(function() {
		var $pcontent = $(this).next('.pcontent');
		if ($pcontent.is(':hidden')) {
			$pcontent.slideDown();
			$(this).addClass('close');
		}else{
			$pcontent.fadeOut();
			$(this).removeClass('close');
		}
	});
    });
